package com.geoquiz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.geoquiz.app.ui.HomeScreen
import com.geoquiz.app.ui.QuizScreen
import com.geoquiz.app.ui.ResultScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavHost()
                }
            }
        }
    }
}

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val viewModel: GameViewModel = viewModel()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onStage1Click = {
                    viewModel.startQuiz(QuizMode.FLAG_TO_NAME)
                    navController.navigate("quiz/1")
                },
                onStage2Click = {
                    viewModel.startQuiz(QuizMode.CAPITAL_TO_NAME)
                    navController.navigate("quiz/2")
                }
            )
        }
        composable("quiz/{stage}") { backStackEntry ->
            val stage = backStackEntry.arguments?.getString("stage") ?: "1"
            QuizScreen(
                viewModel = viewModel,
                stageTitle = if (stage == "1") "المرحلة 1: الأعلام" else "المرحلة 2: العواصم",
                onFinished = {
                    navController.navigate("result/${viewModel.score.value}/${viewModel.questions.value.size}") {
                        popUpTo("home")
                    }
                }
            )
        }
        composable("result/{score}/{total}") { backStackEntry ->
            val score = backStackEntry.arguments?.getString("score")?.toIntOrNull() ?: 0
            val total = backStackEntry.arguments?.getString("total")?.toIntOrNull() ?: 0
            ResultScreen(
                score = score,
                total = total,
                onHomeClick = {
                    navController.navigate("home") {
                        popUpTo("home") { inclusive = true }
                    }
                }
            )
        }
    }
}
